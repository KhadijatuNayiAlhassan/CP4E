public class Nayi2{
    int p;
       public static void main(String[]args){
        int p = 12;
            int i = p;
            System.out.print(p);
            while(i){
                if(i%2 == 0 && i >1){
                    int a = i/2;
                    System.out.print(a);
                }
                else if(i%2 != 0 && i>0){
                    int a = 3*i +1;
                    System.out.print(a);
                }
                int i = a;
            }
    
    
        }
}
    




    }
    
}