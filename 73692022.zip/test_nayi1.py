from nayi1 import find_len,find_num
def main():
    print(find_len("Python Ashesi Ghana"))
    print(find_num(12))
main()
